# Quick Sign Up Landing Page

Landing page for Nexxusynner email-only offers.  

- Mobile + Desktop responsive
- Email-only (fast approval)
- Optional subID/campaign tracking
- Privacy & T&C modal included